import requests
from bs4 import BeautifulSoup
import pprint

Response = requests.get("https://news.ycombinator.com/news")
soup = BeautifulSoup(Response.text, "html.parser")
links = soup.select(".titleline")
subtext = soup.select(".subtext")


def creat_SortedStories_byvotes(hnlists):
    return sorted(hnlists, key=lambda k: k["votes"], reverse=True)


def creat_custom_hackernews(linkss, subtext):
    hacker_news = []
    for index, item in enumerate(linkss):
        title = item.getText()
        href = item.get("href", None)
        vote = subtext[index].select(".score")
        if len(vote):
            v_points = int(vote[0].getText().replace(" points", " "))
            if v_points >= 50:
                hacker_news.append({"title": title, "link": href, "votes": v_points})
    return creat_SortedStories_byvotes(hacker_news)


pprint.pprint(creat_custom_hackernews(links, subtext))
